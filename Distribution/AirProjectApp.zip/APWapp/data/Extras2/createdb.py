import sqlite3 as sql

#00b300 good
#99ff33 satisfactory
#ffff1a medium
#ff8000 poor
#ff0000 very poor
#800000 dangerous

conn=sql.connect('ColorCode.db')
cur=conn.cursor()

cur.execute("create table color(pollutant char(20),lowlevel int,highlevel int,color varchar(20),condition char(15));")

cur.execute("insert into color values('pm10',0,50,'#00b300','good');")
cur.execute("insert into color values('pm10',50,100,'#99ff33','satisfactory');")
cur.execute("insert into color values('pm10',100,250,'#ffff1a','medium');")
cur.execute("insert into color values('pm10',250,350,'#ff8000','poor');")
cur.execute("insert into color values('pm10',350,430,'#ff0000','very poor');")
cur.execute("insert into color values('pm10',430,1000,'#800000','dangerous');")

cur.execute("insert into color values('pm25',0,30,'#00b300','good');")
cur.execute("insert into color values('pm25',30,60,'#99ff33','satisfactory');")
cur.execute("insert into color values('pm25',60,90,'#ffff1a','medium');")
cur.execute("insert into color values('pm25',90,120,'#ff8000','poor');")
cur.execute("insert into color values('pm25',120,250,'#ff0000','very poor');")
cur.execute("insert into color values('pm25',250,1000,'#800000','dangerous');")

cur.execute("insert into color values('aqi',0,50,'#00b300','good');")
cur.execute("insert into color values('aqi',50,100,'#99ff33','satisfactory');")
cur.execute("insert into color values('aqi',100,200,'#ffff1a','medium');")
cur.execute("insert into color values('aqi',200,300,'#ff8000','poor');")
cur.execute("insert into color values('aqi',300,400,'#ff0000','very poor');")
cur.execute("insert into color values('aqi',400,1000,'#800000','dangerous');")

cur.execute("insert into color values('no2',0,40,'#00b300','good');")
cur.execute("insert into color values('no2',40,80,'#99ff33','satisfactory');")
cur.execute("insert into color values('no2',80,180,'#ffff1a','medium');")
cur.execute("insert into color values('no2',180,280,'#ff8000','poor');")
cur.execute("insert into color values('no2',280,400,'#ff0000','very poor');")
cur.execute("insert into color values('no2',400,1000,'#800000','dangerous');")

cur.execute("insert into color values('o3',0,50,'#00b300','good');")
cur.execute("insert into color values('o3',50,100,'#99ff33','satisfactory');")
cur.execute("insert into color values('o3',100,168,'#ffff1a','medium');")
cur.execute("insert into color values('o3',168,208,'#ff8000','poor');")
cur.execute("insert into color values('o3',208,748,'#ff0000','very poor');")
cur.execute("insert into color values('o3',748,2000,'#800000','dangerous');")

cur.execute("insert into color values('co',0,1,'#00b300','good');")
cur.execute("insert into color values('co',1,2,'#99ff33','satisfactory');")
cur.execute("insert into color values('co',2,10,'#ffff1a','medium');")
cur.execute("insert into color values('co',10,17,'#ff8000','poor');")
cur.execute("insert into color values('co',17,34,'#ff0000','very poor');")
cur.execute("insert into color values('co',34,1000,'#800000','dangerous');")

cur.execute("insert into color values('so2',0,40,'#00b300','good');")
cur.execute("insert into color values('so2',40,80,'#99ff33','satisfactory');")
cur.execute("insert into color values('so2',80,380,'#ffff1a','medium');")
cur.execute("insert into color values('so2',380,800,'#ff8000','poor');")
cur.execute("insert into color values('so2',800,1600,'#ff0000','very poor');")
cur.execute("insert into color values('so2',1600,5000,'#800000','dangerous');")

cur.execute("insert into color values('nh3',0,200,'#00b300','good');")
cur.execute("insert into color values('nh3',200,400,'#99ff33','satisfactory');")
cur.execute("insert into color values('nh3',400,800,'#ffff1a','medium');")
cur.execute("insert into color values('nh3',800,1200,'#ff8000','poor');")
cur.execute("insert into color values('nh3',1200,1800,'#ff0000','very poor');")
cur.execute("insert into color values('nh3',1800,6000,'#800000','dangerous');")


cur.execute("insert into color values('dew',0,5000,'#99ff33','satisfactory');")                                


pollutant={'pm10':0,'pm25':0,'co':0,'dew':0,'no2':0,'o3':0}
for matter in pollutant.keys():
	print(matter)
	cmd="insert into color values('"+matter+"',0,0,'#ffffff','Not Available');"
	cur.execute(cmd)
cur.execute("insert into color values('aqi',0,0,'#ffffff','Not Available');",())
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('pm10'))
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('pm25'))
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('co'))
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('dew'))
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('no2'))
cur.execute("insert into color values(?,0,0,'#ffffff','Not Available');",('o3'))


#create table colorcode(pollutant char(20),level float(5),color varchar(20));

conn.commit()
cur.execute("select * from color;")
data=cur.fetchall()
print(data)

