"""
#importing library
from tkinter import *
#creating window
from PIL import Image, ImageTk
window = Tk()
#Title
window.title('Grand Canyon')
#display attributes
lab = Label(window, width = 500, height = 500)
lab.pack()
#GIF in my_image variable
#Give the entire file address along with the file name and gif extension
w3_main = Image.open('data\\loading.gif')
w3_main1 = w3_main.resize((400,160), Image.ANTIALIAS)
w3_pic = ImageTk.PhotoImage(w3_main1)
lab.config(image=w3_pic)
# window.after(1000,up)
window.mainloop()
"""
from tkinter import *
import ctypes
# import time
# import os
u32=ctypes.windll.user32
u32.SetProcessDPIAware()
swidth=u32.GetSystemMetrics(0)
shight=u32.GetSystemMetrics(1)

width,height=230,100
xspace=int(swidth/2-width/2)
yspace=int(shight/2-height/2)
loadingw = Tk()
loadingw.overrideredirect(1)
loadingw.geometry("%dx%d+%d+%d"%(width,height,xspace,yspace))
loadingw.resizable(0,0)
loadingw.withdraw()
loadingw.deiconify()
frameCnt = 63
frames = [PhotoImage(file='data\\loadingmain.gif',format = f'gif -index {i}') for i in range(frameCnt)]
def update(ind):
    frame = frames[ind]
    ind += 1
    if ind == frameCnt:
        ind = 0
    label.configure(image=frame)
    loadingw.after(20, update, ind)
label = Label(loadingw)
label.grid(row=0,column=0)
loadingw.after(1200, update, 0)
lbname=Label(loadingw,text="Sending\nMail",font=("Helvetica", 20))
lbname.grid(row=0,column=1)