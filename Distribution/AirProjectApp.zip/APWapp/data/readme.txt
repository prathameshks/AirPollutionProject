*To start the app run the main.py file

*do not delete aany file from this project other wise it will not work

*this app is made only for education purpose

*you need to install following libraries in your python3.x installed
#pip install requests
import requests
#pip install pillow
from PIL import Image, ImageTk
#pip install matplotlib
import matplotlib.pyplot as plt

*Default installed
tkinter
sqlite3
webbrowser
os
urllib.request
datetime
smtplib
email.message.EmailMessage 
ctypes

